import java.util.ArrayList;
import java.util.Arrays;
import java.net.*;
import java.nio.ByteBuffer;


public class PacketNumberingAndData {

    private final static int packetSize = 64;
    private final static int recvBufferSize = 1024;
    private final static int packetThreshold = 32;
    private final static int resetNumberingInMillis = 1000;

    private static int recv_pkt_count = 0, not_in_order_pkt_count = 0, sent_pkt_count = 0;
    private int send_i = 0, play_i = -1;

    private byte[][] recvBuffer = new byte[recvBufferSize][packetSize];

    private static volatile long startTime = System.currentTimeMillis();

    //append sequence a number to the packet
    byte[] addNumbers(byte[] packet) {

        byte[] numbered_packet = Arrays.copyOf(packet, packetSize);
        ByteBuffer bytebuffer = ByteBuffer.allocate(4);
        bytebuffer.putInt(send_i);
        byte[] data = bytebuffer.array();
        System.arraycopy(data, 0, numbered_packet, packetSize - 4, 4);
        sent_pkt_count++;
        send_i++;
        return numbered_packet;

    }

    private int getNumber(byte[] packet) {

        byte[] temp = new byte[4];
        System.arraycopy(packet, packetSize - 4, temp, 0, 4);
        int pktNumber = ByteBuffer.wrap(temp).getInt();

        return pktNumber;
    }

    private byte[] getNumRemovedPacket(byte[] packet) {
        return Arrays.copyOf(packet, packetSize - 4);
    }

    void appendPacket(byte[] packet) {

        recv_pkt_count++;


        int pktNumber = getNumber(packet);

        if (pktNumber > play_i) {
            recvBuffer[pktNumber % recvBufferSize] = getNumRemovedPacket(packet);
        } else not_in_order_pkt_count++;

        if (System.currentTimeMillis() > startTime + resetNumberingInMillis) {
            System.out.println(" Losses " + (sent_pkt_count - recv_pkt_count) + " Not in order packets " + not_in_order_pkt_count);
            startTime = System.currentTimeMillis();
            sent_pkt_count = 0;
            recv_pkt_count = 0;
            not_in_order_pkt_count = 0;

        }

    }

    byte[] getPacket() {

        while (true) {
            int count = 0;
            for (int i = 0; i < recvBufferSize; i++) {
                if (recvBuffer[i] != null) count++;
            }
            if (count > packetThreshold) break;

        }

       // byte[] bytesToPlay = new byte[(packetSize-4) * recvBufferSize];
        byte[] bytesToPlay = new byte[(packetSize-4)];
        for (int i = 0; i < recvBufferSize; i++) {
            if (recvBuffer[i] != null) {

                int receive_num = getNumber(recvBuffer[i]);

                if (receive_num >= play_i) {
//                    play_i = receive_num;
//                    byte[] p = getNumRemovedPacket(recvBuffer[i]);
//                    System.arraycopy(p, 0, bytesToPlay, i*(packetSize-4), packetSize - 4);
//                    break;

                    play_i = receive_num;
                    bytesToPlay = Arrays.copyOf(recvBuffer[i],recvBufferSize-4);

                    recvBuffer[i] = null;
                }
                recvBuffer[i] = null;

            }

        }


        return bytesToPlay;
    }

/*
	main class written for unit test the serialization and deserialization part
*/

    public static void main(String[] args) {
        PacketNumberingAndData s1 = new PacketNumberingAndData();

        int server_port = 9876;

        try {
            InetAddress server_address = InetAddress.getByName("localhost");
            if (args.length == 0) {
                System.out.println("Running unit testing client for testing Serialization and deSerialization");
                DatagramSocket socket = new DatagramSocket();
                try {
                    Thread.sleep(10);
                } catch (Exception ignored) {
                }
                for (int i = 2000; i < 2100; i++) {


                    ByteBuffer b = ByteBuffer.allocate(4);
                    b.putInt(i);
                    byte[] data = b.array();

                    byte[] data_serial = s1.addNumbers(data);
                    DatagramPacket packet = new DatagramPacket(data_serial, data_serial.length, server_address, server_port);
                    System.out.println("sending packet containing int value of" + i);
                    socket.send(packet);
                }
            } else if (args.length == 1) {
                try {
                    Thread.sleep(1000);
                } catch (Exception ignored) {
                }

                System.out.println("AD");
                DatagramSocket socket = new DatagramSocket(server_port);
                while (true) {
                    System.out.println("receiving packet");
                    DatagramPacket packet = new DatagramPacket(new byte[packetSize], packetSize);                // Prepare the packet for receive


                    socket.receive(packet);


                    s1.appendPacket(packet.getData());
                    byte[] temp = s1.getPacket();

                    try {
                        Thread.sleep(100);
                    } catch (Exception e) {
                        e.printStackTrace();
                        break;
                    }

                    ByteBuffer wrapped = ByteBuffer.wrap(temp);
                    int a = wrapped.getInt();

                    System.out.println("Packet Contains : " + a);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

}

